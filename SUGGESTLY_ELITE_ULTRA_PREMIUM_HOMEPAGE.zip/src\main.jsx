// This file is no longer needed - we're using pure HTML/CSS/JavaScript
// The main application is now in index.html

console.log("SUGGESTLY ELITE - Pure HTML/CSS/JavaScript Version");

// Redirect to the main HTML file
window.location.href = "/index.html";
