import React from "react";

function SimpleTest() {
  console.log("SimpleTest component is rendering");
  return (
    <div>
      <h1>Hello World</h1>
      <p>React is working!</p>
    </div>
  );
}

export default SimpleTest;
